"""Operational data adapters."""
