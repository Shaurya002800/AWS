"""Reproducible synthetic resurrection experiments."""
